<?php
/**
 * Plugin Name:       Umrah Price Calculator
 * Description:       Advanced tool to calculate price of Umrah based on the custom choices from the Pilgrims.
 * Version:           1.2.0
 * Author:            Sabir Ishtiaq
 * License:           All Rights Reserved-Tawaf E Haram Travel
 * Text Domain:       dynamic-travel-pricing
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct access bypass
}

class Dynamic_Travel_Pricing_Engine {

    private $fields_table;
    private $pricing_table;
    private $leads_table;

    public function __construct() {
        global $wpdb;
        $this->fields_table  = $wpdb->prefix . 'dtp_fields';
        $this->pricing_table = $wpdb->prefix . 'dtp_pricing';
        $this->leads_table   = $wpdb->prefix . 'dtp_leads';

        // Activation & Setup Hook
        register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );

        // Admin Dashboards and Actions
        add_action( 'admin_menu', array( $this, 'create_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'process_admin_settings_updates' ) );

        // Frontend Assets & Core Shortcode
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
        add_shortcode( 'travel_pricing_calculator', array( $this, 'render_calculator_shortcode' ) );

        // Secure AJAX Endpoints
        add_action( 'wp_ajax_dtp_calculate_price', array( $this, 'handle_price_calculation' ) );
        add_action( 'wp_ajax_nopriv_dtp_calculate_price', array( $this, 'handle_price_calculation' ) );
        add_action( 'wp_ajax_dtp_submit_lead', array( $this, 'handle_lead_submission' ) );
        add_action( 'wp_ajax_nopriv_dtp_submit_lead', array( $this, 'handle_lead_submission' ) );
    }

    /**
     * Creates Custom Relational Database Tables upon plugin activation
     */
    public function activate_plugin() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql1 = "CREATE TABLE {$this->fields_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            field_name varchar(255) NOT NULL,
            field_type varchar(50) NOT NULL,
            field_order int(11) DEFAULT 0,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql2 = "CREATE TABLE {$this->pricing_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            field_id bigint(20) NOT NULL,
            option_label varchar(255) DEFAULT '',
            option_value varchar(255) DEFAULT '',
            season_slug varchar(100) NOT NULL,
            price decimal(10,2) DEFAULT 0.00,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql3 = "CREATE TABLE {$this->leads_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            customer_phone varchar(50) NOT NULL,
            package_payload longtext NOT NULL,
            total_price decimal(10,2) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql1 );
        dbDelta( $sql2 );
        dbDelta( $sql3 );

        if ( ! get_option( 'dtp_seasons' ) ) {
            update_option( 'dtp_seasons', array(
                'jan_july' => 'January – July',
                'aug_dec'  => 'August – December'
            ) );
        }
    }

    public function create_admin_menu() {
        add_menu_page(
            'Travel Engine Dashboard', 'Travel Pricing', 'manage_options', 
            'dtp-dashboard', array( $this, 'render_admin_dashboard' ), 'dashicons-calculator', 25
        );
        add_submenu_page(
            'dtp-dashboard', 'Manage Dynamic Fields', 'Fields & Rules', 'manage_options',
            'dtp-fields', array( $this, 'render_admin_fields_page' )
        );
        add_submenu_page(
            'dtp-dashboard', 'Customer Leads / Bookings', 'Leads Received', 'manage_options',
            'dtp-leads', array( $this, 'render_admin_leads_page' )
        );
    }

    /**
     * Admin Controller: Secure Form Processors
     */
    public function process_admin_settings_updates() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;

        // 1. Process Season Management & System Variables Updates
        if ( isset( $_POST['dtp_save_seasons_nonce'] ) && wp_verify_nonce( $_POST['dtp_save_seasons_nonce'], 'dtp_save_seasons' ) ) {
            if ( isset( $_POST['seasons_keys'] ) && is_array( $_POST['seasons_keys'] ) ) {
                $updated_seasons = array();
                foreach ( $_POST['seasons_keys'] as $index => $key ) {
                    $slug = sanitize_title( $key );
                    $label = sanitize_text_field( $_POST['seasons_labels'][$index] );
                    if ( ! empty( $slug ) && ! empty( $label ) ) {
                        $updated_seasons[$slug] = $label;
                    }
                }
                update_option( 'dtp_seasons', $updated_seasons );
                wp_redirect( admin_url( 'admin.php?page=dtp-dashboard&status=success' ) );
                exit;
            }
        }

        // 2. Process Field Structures & Dynamic Matrix Updates
        if ( isset( $_POST['dtp_field_config_nonce'] ) && wp_verify_nonce( $_POST['dtp_field_config_nonce'], 'dtp_field_config' ) ) {
            if ( isset( $_POST['action_type'] ) && $_POST['action_type'] === 'add_field' ) {
                $name = sanitize_text_field( $_POST['new_field_name'] );
                $type = sanitize_text_field( $_POST['new_field_type'] );
                if ( ! empty( $name ) && ! empty( $type ) ) {
                    $wpdb->insert( $this->fields_table, array( 'field_name' => $name, 'field_type' => $type ) );
                }
            }

            if ( isset( $_POST['action_type'] ) && $_POST['action_type'] === 'delete_field' ) {
                $field_id = intval( $_POST['target_field_id'] );
                $wpdb->delete( $this->fields_table, array( 'id' => $field_id ) );
                $wpdb->delete( $this->pricing_table, array( 'field_id' => $field_id ) );
            }

            if ( isset( $_POST['action_type'] ) && $_POST['action_type'] === 'save_matrix' ) {
                $field_id = intval( $_POST['target_field_id'] );
                $wpdb->delete( $this->pricing_table, array( 'field_id' => $field_id ) );

                if ( isset( $_POST['matrix'] ) && is_array( $_POST['matrix'] ) ) {
                    foreach ( $_POST['matrix'] as $row_index => $seasons_data ) {
                        $opt_label = isset( $_POST['opt_labels'][$row_index] ) ? sanitize_text_field( $_POST['opt_labels'][$row_index] ) : 'Direct Option';
                        $opt_val   = sanitize_title( $opt_label );
                        
                        foreach ( $seasons_data as $season_slug => $price_value ) {
                            $wpdb->insert( $this->pricing_table, array(
                                'field_id'     => $field_id,
                                'option_label' => $opt_label,
                                'option_value' => $opt_val,
                                'season_slug'  => sanitize_text_field( $season_slug ),
                                'price'        => floatval( $price_value )
                            ) );
                        }
                    }
                }
            }
            wp_redirect( admin_url( 'admin.php?page=dtp-fields&status=success' ) );
            exit;
        }
    }

    /**
     * Admin View: Main Dashboard / Season Configuration Screen
     */
    public function render_admin_dashboard() {
        $seasons = get_option( 'dtp_seasons', array() );
        ?>
        <div class="wrap">
            <h1>Dynamic Travel Package Pricing Engine</h1>
            <p>Welcome to the core control matrix panel. Define global travel operational seasons here.</p>
            <hr />
            <div class="card" style="max-width: 600px; padding: 20px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2>Manage Travel Seasons</h2>
                <form method="POST" action="">
                    <?php wp_nonce_field( 'dtp_save_seasons', 'dtp_save_seasons_nonce' ); ?>
                    <table class="widefat striped" id="seasons-table" style="margin-bottom: 15px;">
                        <thead>
                            <tr>
                                <th>Season Unique Identifier (Slug)</th>
                                <th>Display Label Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( ! empty( $seasons ) ) : foreach ( $seasons as $slug => $label ) : ?>
                                <tr>
                                    <td><input type="text" name="seasons_keys[]" value="<?php echo esc_attr( $slug ); ?>" readonly class="regular-text" style="background:#eee;"/></td>
                                    <td><input type="text" name="seasons_labels[]" value="<?php echo esc_attr( $label ); ?>" class="regular-text" required /></td>
                                    <td><button type="button" class="button button-link-delete" onclick="this.closest('tr').remove();">Remove</button></td>
                                </tr>
                            <?php endforeach; else : ?>
                                <tr>
                                    <td><input type="text" name="seasons_keys[]" placeholder="e.g. peak_2026" class="regular-text" required /></td>
                                    <td><input type="text" name="seasons_labels[]" placeholder="e.g. Peak Season 2026" class="regular-text" required /></td>
                                    <td><button type="button" class="button button-link-delete" onclick="this.closest('tr').remove();">Remove</button></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <button type="button" class="button action" id="add-season-row-btn">+ Add Custom Season</button>
                    <input type="submit" class="button button-primary" value="Save System Seasons" style="float: right;" />
                </form>
            </div>
        </div>
        <script>
            document.getElementById('add-season-row-btn').addEventListener('click', function() {
                var tbody = document.querySelector('#seasons-table tbody');
                var row = document.createElement('tr');
                row.innerHTML = '<td><input type="text" name="seasons_keys[]" placeholder="e.g. off_season" class="regular-text" required /></td>' +
                                '<td><input type="text" name="seasons_labels[]" placeholder="e.g. Off Season" class="regular-text" required /></td>' +
                                '<td><button type="button" class="button button-link-delete" onclick="this.closest(\'tr\').remove();">Remove</button></td>';
                tbody.appendChild(row);
            });
        </script>
        <?php
    }

    /**
     * Admin View: Field Engine & Matrix Pricing Configurations Screen
     */
    public function render_admin_fields_page() {
        global $wpdb;
        $fields  = $wpdb->get_results( "SELECT * FROM {$this->fields_table} ORDER BY field_order ASC" );
        $seasons = get_option( 'dtp_seasons', array() );
        ?>
        <div class="wrap">
            <h1>Dynamic Rules & Custom Variable Engine</h1>
            <p>Generate fields dynamically, build custom options, and configure operational seasonal pricing grids below.</p>
            <div class="notice notice-warning" style="margin-left:0; max-width:850px;">
                <p><strong>Note for Room Calculations Matrix:</strong> Name a field exactly <strong>Hotel</strong> or <strong>Accommodation</strong> to activate the per-night multiplication factor logic pipeline dynamically.</p>
            </div>
            <hr />

            <div class="card" style="background:#fff; padding:20px; margin-bottom:20px;">
                <h2>Add New Field Framework Node</h2>
                <form method="POST" action="">
                    <?php wp_nonce_field( 'dtp_field_config', 'dtp_field_config_nonce' ); ?>
                    <input type="hidden" name="action_type" value="add_field" />
                    <input type="text" name="new_field_name" placeholder="Field Name (e.g., Hotel, Optional Upgrades)" class="regular-text" required />
                    <select name="new_field_type" required>
                        <option value="dropdown">Dropdown Options List</option>
                        <option value="addon_group">Checkbox Selectable Addons Group (Multi-Select Grid)</option>
                        <option value="direct">Singular Dynamic Field Checkbox</option>
                    </select>
                    <input type="submit" class="button button-primary" value="Generate Structural Node" />
                </form>
            </div>

            <h2>Configured Engine Variable Frameworks</h2>
            <?php if ( ! empty( $fields ) ) : foreach ( $fields as $field ) : 
                $matrix_rules = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->pricing_table} WHERE field_id = %d", $field->id ) );
                ?>
                <div class="card" style="background:#fff; padding:20px; margin-bottom:20px; border-left: 4px solid #0073aa;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h3><strong>Variable Name:</strong> <?php echo esc_html( $field->field_name ); ?> 
                            <span style="font-weight:normal; font-size:12px; background:#eee; padding:3px 8px; border-radius:3px; margin-left:10px;">
                                Type: <?php echo esc_html( strtoupper( $field->field_type ) ); ?>
                            </span>
                            <?php if ( strtolower($field->field_name) === 'hotel' || strtolower($field->field_name) === 'accommodation' ) : ?>
                                <span style="font-weight:bold; font-size:11px; background:#fff3cd; color:#856404; padding:3px 8px; border-radius:3px; border:1px solid #ffeeba; margin-left:5px;">
                                    ★ Per-Night Calculation Rules Active
                                </span>
                            <?php endif; ?>
                        </h3>
                        <form method="POST" action="" onsubmit="return confirm('Are you sure you want to permanently wipe out this node and its related price data?');">
                            <?php wp_nonce_field( 'dtp_field_config', 'dtp_field_config_nonce' ); ?>
                            <input type="hidden" name="action_type" value="delete_field" />
                            <input type="hidden" name="target_field_id" value="<?php echo intval( $field->id ); ?>" />
                            <input type="submit" class="button button-link-delete" value="Delete This Field" style="color:#d63638;" />
                        </form>
                    </div>
                    
                    <h4 style="margin-top:10px; text-decoration: underline;">Pricing Engine Rule Set Matrix</h4>
                    <form method="POST" action="">
                        <?php wp_nonce_field( 'dtp_field_config', 'dtp_field_config_nonce' ); ?>
                        <input type="hidden" name="action_type" value="save_matrix" />
                        <input type="hidden" name="target_field_id" value="<?php echo intval( $field->id ); ?>" />

                        <table class="widefat striped" id="matrix-table-<?php echo intval( $field->id ); ?>" style="margin-bottom:10px;">
                            <thead>
                                <tr>
                                    <?php if ( $field->field_type === 'dropdown' || $field->field_type === 'addon_group' ) : ?>
                                        <th>Option Entry Display Label</th>
                                    <?php endif; ?>
                                    <?php foreach ( $seasons as $slug => $label ) : ?>
                                        <th>Base Flat Addon Fee: <?php echo esc_html( $label ); ?> (£)</th>
                                    <?php endforeach; ?>
                                    <?php if ( $field->field_type === 'dropdown' || $field->field_type === 'addon_group' ) : ?>
                                        <th>Actions</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                if ( $field->field_type === 'direct' ) {
                                    echo '<tr>';
                                    foreach ( $seasons as $slug => $label ) {
                                        $current_val = 0;
                                        foreach ( $matrix_rules as $rule ) {
                                            if ( $rule->season_slug === $slug ) { $current_val = $rule->price; break; }
                                        }
                                        echo '<td>
                                                <input type="hidden" name="opt_labels[0]" value="Direct Price Configuration" />
                                                <input type="number" step="0.01" name="matrix[0]['.esc_attr($slug).']" value="'.esc_attr($current_val).'" class="small-text" required />
                                              </td>';
                                    }
                                    echo '</tr>';
                                } else {
                                    $grouped_rows = array();
                                    foreach ( $matrix_rules as $rule ) {
                                        $grouped_rows[$rule->option_label][$rule->season_slug] = $rule->price;
                                    }

                                    if ( ! empty( $grouped_rows ) ) {
                                        $row_id = 0;
                                        foreach ( $grouped_rows as $label => $season_prices ) {
                                            echo '<tr>';
                                            echo '<td><input type="text" name="opt_labels['.$row_id.']" value="'.esc_attr($label).'" class="regular-text" required /></td>';
                                            foreach ( $seasons as $slug => $s_label ) {
                                                $price = isset( $season_prices[$slug] ) ? $season_prices[$slug] : 0;
                                                echo '<td><input type="number" step="0.01" name="matrix['.$row_id.']['.esc_attr($slug).']" value="'.esc_attr($price).'" class="small-text" required /></td>';
                                            }
                                            echo '<td><button type="button" class="button button-link-delete" onclick="this.closest(\'tr\').remove();">Remove Option Row</button></td>';
                                            echo '</tr>';
                                            $row_id++;
                                        }
                                    } else {
                                        echo '<tr>';
                                        echo '<td><input type="text" name="opt_labels[0]" placeholder="e.g. Premium Item Option" class="regular-text" required /></td>';
                                        foreach ( $seasons as $slug => $s_label ) {
                                            echo '<td><input type="number" step="0.01" name="matrix[0]['.esc_attr($slug).']" value="0.00" class="small-text" required /></td>';
                                        }
                                        echo '<td><button type="button" class="button button-link-delete" onclick="this.closest(\'tr\').remove();">Remove Option Row</button></td>';
                                        echo '</tr>';
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php if ( $field->field_type === 'dropdown' || $field->field_type === 'addon_group' ) : ?>
                            <button type="button" class="button action" onclick="dtp_add_matrix_row(<?php echo intval( $field->id ); ?>, <?php echo esc_attr( json_encode( array_keys( $seasons ) ) ); ?>)">+ Create Item Matrix Row Mapping</button>
                        <?php endif; ?>
                        <input type="submit" class="button button-primary" value="Save Price Configurations Matrix Grid" style="float: right;" />
                        <div style="clear:both;"></div>
                    </form>
                </div>
            <?php endforeach; else : ?>
                <div class="notice notice-info"><p>There are no global custom layout dynamic mapping fields in system database storage arrays yet.</p></div>
            <?php endif; ?>
        </div>
        <script>
            function dtp_add_matrix_row(fieldId, seasonsArray) {
                var tbody = document.querySelector('#matrix-table-' + fieldId + ' tbody');
                var rowCount = tbody.children.length;
                var row = document.createElement('tr');
                
                var htmlStr = '<td><input type="text" name="opt_labels['+rowCount+']" placeholder="Custom Label Name" class="regular-text" required /></td>';
                seasonsArray.forEach(function(slug) {
                    htmlStr += '<td><input type="number" step="0.01" name="matrix['+rowCount+']['+slug+']" value="0.00" class="small-text" required /></td>';
                });
                htmlStr += '<td><button type="button" class="button button-link-delete" onclick="this.closest(\'tr\').remove();">Remove Option Row</button></td>';
                
                row.innerHTML = htmlStr;
                tbody.appendChild(row);
            }
        </script>
        <?php
    }

    /**
     * Admin View: Display Leads Received Data Processing Panel Screen
     */
    public function render_admin_leads_page() {
        global $wpdb;
        $leads = $wpdb->get_results( "SELECT * FROM {$this->leads_table} ORDER BY id DESC" );
        ?>
        <div class="wrap">
            <h1>Customer Leads Through Pricing Calculator</h1>
            <p>Review customer booking inquiries generated through the Dynamic Package Frontend Calculator Interface.</p>
            <hr />
            <table class="widefat striped regular">
                <thead>
                    <tr>
                        <th>ID Reference</th>
                        <th>Client Details</th>
                        <th>Custom Package Details</th>
                        <th>Quoted Target Price</th>
                        <th>Submission Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( ! empty( $leads ) ) : foreach ( $leads as $lead ) : 
                        $payload = json_decode( $lead->package_payload, true );
                        ?>
                        <tr>
                            <td><strong>#<?php echo intval( $lead->id ); ?></strong></td>
                            <td>
                                <strong>Name:</strong> <?php echo esc_html( $lead->customer_name ); ?><br />
                                <strong>Email:</strong> <?php echo esc_html( $lead->customer_email ); ?><br />
                                <strong>Phone:</strong> <?php echo esc_html( $lead->customer_phone ); ?>
                            </td>
                            <td>
                                <div style="font-size:11px; background:#f9f9f9; padding:8px; border: 1px solid #ddd; max-height:120px; overflow-y:auto; border-radius:3px;">
                                    <?php 
                                    if( is_array($payload) ) {
                                        foreach( $payload as $key => $val ) {
                                            if( is_array($val) ) {
                                                echo '<strong>' . esc_html(ucfirst(str_replace('_', ' ', $key))) . ':</strong> ' . esc_html(implode(', ', $val)) . '<br />';
                                            } else {
                                                echo '<strong>' . esc_html(ucfirst(str_replace('_', ' ', $key))) . ':</strong> ' . esc_html($val) . '<br />';
                                            }
                                        }
                                    } else {
                                        echo esc_html($lead->package_payload);
                                    }
                                    ?>
                                </div>
                            </td>
                            <td><span style="font-size: 16px; color: #46b450; font-weight: bold;">£<?php echo esc_html( number_format( $lead->total_price, 2 ) ); ?></span></td>
                            <td><?php echo esc_html( $lead->created_at ); ?></td>
                        </tr>
                    <?php endforeach; else : ?>
                        <tr><td colspan="5">No structural interaction client queries captured inside database infrastructure blocks yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Injection Frontend Controller Core Engine Styles / Frontend Scripts
     */
    public function enqueue_frontend_assets() {
        wp_register_style( 'dtp-frontend-styles', false );
        wp_enqueue_style( 'dtp-frontend-styles' );
        
        $custom_css = "
            .dtp-calculator-box { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; max-width: 650px; margin: 20px auto; font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
            .dtp-title { font-size: 22px; color: #044343; font-weight: bold; margin-bottom: 20px; text-align: left; }
            
            .dtp-flex-row { display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 4px; }
            .dtp-flex-row .dtp-form-group { flex: 1; min-width: calc(50% - 8px); }
            
            .dtp-form-group { margin-bottom: 18px; }
            .dtp-form-group.full-width { flex: 0 0 100% !important; width: 100% !important; }
            .dtp-form-group label { display: block; font-weight: 600; font-size: 14px; margin-bottom: 8px; color: #334155; }
            .dtp-select, .dtp-input-num { width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 15px; outline: none; background:#fff;}
            
            .dtp-addon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; margin-top: 8px; }
            .dtp-addon-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; cursor: pointer; transition: all 0.2s ease; }
            .dtp-addon-card:hover { border-color: #046c4e; background: #f8fafc; }
            .dtp-addon-left { display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; color: #1e293b; }
            .dtp-addon-left input[type='checkbox'] { width: 16px; height: 16px; margin: 0; accent-color: #046c4e; cursor: pointer; }
            .dtp-addon-price { font-weight: 600; font-size: 14px; color: #046c4e; }
            
            .dtp-checkbox-label { display: flex !important; align-items: center; gap: 8px; font-weight: 500 !important; cursor:pointer;}
            .dtp-checkbox-label input { width:18px; height:18px; margin:0; }
            
            .dtp-total-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 20px; margin-top: 20px; text-align: left; display:flex; justify-content:space-between; align-items:center; }
            .dtp-total-text { font-size: 13px; color: #166534; font-weight: 500; line-height:1.4; }
            .dtp-total-price { font-size: 34px; color: #14532d; font-weight: 800; }
            .dtp-btn-submit { width: 100%; background: #046c4e; color: #ffffff; border: none; padding: 14px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 15px; text-align:center; transition: background 0.2s; }
            .dtp-btn-submit:hover { background: #065f46; }
            
            .dtp-modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 99999; justify-content: center; align-items: center; }
            .dtp-modal-content { background: #fff; padding: 30px; border-radius: 12px; max-width: 400px; width: 90%; position: relative; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
            .dtp-modal-close { position: absolute; top: 12px; right: 15px; font-size: 20px; cursor: pointer; color: #64748b; font-weight:bold;}
            
            .dtp-success-pane { display: none; text-align: center; padding: 20px 10px; }
            .dtp-success-pane h4 { font-size: 18px; color: #044343; margin: 0 0 10px 0; font-weight: bold; }
            .dtp-success-pane p { font-size: 14px; color: #475569; margin: 0; line-height: 1.5; }
        ";
        wp_add_inline_style( 'dtp-frontend-styles', $custom_css );
    }

    /**
     * Frontend View Render Controller via Shortcode Engine Integration Pipeline Loop
     */
    public function render_calculator_shortcode() {
        global $wpdb;
        $fields  = $wpdb->get_results( "SELECT * FROM {$this->fields_table} ORDER BY field_order ASC" );
        $seasons = get_option( 'dtp_seasons', array() );

        if ( empty( $seasons ) ) {
            return '<p style="color:red;">Engine Error Configuration Notice: Set up seasons in the admin menu backend workspace before rendering system calculator parameters layout structures.</p>';
        }

        ob_start();
        ?>
        <div class="dtp-calculator-box">
            <div class="dtp-title">Build Your Custom Package Live</div>
            <form id="dtp-calc-form">
                
                <div class="dtp-flex-row">
                    <div class="dtp-form-group">
                        <label for="dtp_season_select">Select Your Travel Season</label>
                        <select name="dtp_season" id="dtp_season_select" class="dtp-select" onchange="dtp_trigger_live_recalculation();">
                            <?php foreach ( $seasons as $slug => $label ) : ?>
                                <option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <?php 
                    $dropdown_or_direct_fields = array_filter($fields, function($f) {
                        return $f->field_type === 'dropdown' || $f->field_type === 'direct';
                    });
                    
                    $addon_group_fields = array_filter($fields, function($f) {
                        return $f->field_type === 'addon_group';
                    });

                    // Row 1, Col 2: Inject next inline field directly beside the season dropdown
                    if ( ! empty( $dropdown_or_direct_fields ) ) {
                        $first_field = array_shift( $dropdown_or_direct_fields );
                        $this->render_frontend_field_item( $first_field, $wpdb );
                    } else {
                        // Empty spacer if no fields are present
                        echo '<div class="dtp-form-group"></div>';
                    }
                    ?>
                </div>

                <div class="dtp-flex-row">
                    <div class="dtp-form-group">
                        <label for="dtp_nights">Umrah Nights (Stay Duration)</label>
                        <input type="number" id="dtp_nights" name="dtp_nights" class="dtp-select" value="7" min="1" step="1" oninput="dtp_trigger_live_recalculation();" onchange="dtp_trigger_live_recalculation();" />
                    </div>
                    <?php 
                    if ( ! empty( $dropdown_or_direct_fields ) ) {
                        $next_field = array_shift( $dropdown_or_direct_fields );
                        $this->render_frontend_field_item( $next_field, $wpdb );
                    } else {
                        echo '<div class="dtp-form-group"></div>';
                    }
                    ?>
                </div>

                <?php if ( ! empty( $dropdown_or_direct_fields ) ) : ?>
                    <div class="dtp-flex-row">
                        <?php 
                        $counter = 0;
                        foreach ( $dropdown_or_direct_fields as $field ) {
                            if ( $counter > 0 && $counter % 2 === 0 ) {
                                echo '</div><div class="dtp-flex-row">';
                            }
                            $this->render_frontend_field_item( $field, $wpdb );
                            $counter++;
                        }
                        // Add spacer flex block item if row has an odd count
                        if ( $counter % 2 !== 0 ) {
                            echo '<div class="dtp-form-group"></div>';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $addon_group_fields ) ) : ?>
                    <div class="dtp-flex-row">
                        <?php foreach ( $addon_group_fields as $field ) : ?>
                            <div class="dtp-form-group full-width">
                                <label style="text-transform: uppercase; letter-spacing: 0.5px; font-size: 13px; color: #64748b; margin-bottom: 12px;">
                                    <?php echo esc_html( $field->field_name ); ?> (Select Any)
                                </label>
                                <div class="dtp-addon-grid" id="addon-grid-<?php echo intval($field->id); ?>">
                                    </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="dtp-flex-row">
                    <div class="dtp-form-group">
                        <label for="dtp_persons">Number of Persons</label>
                        <input type="number" id="dtp_persons" name="dtp_persons" class="dtp-select" value="1" min="1" step="1" oninput="dtp_trigger_live_recalculation();" onchange="dtp_trigger_live_recalculation();" />
                    </div>
                    <div class="dtp-form-group" style="visibility:hidden; opacity:0; pointer-events:none;"></div>
                </div>

                <div class="dtp-total-box">
                    <div class="dtp-total-text">
                        <strong>YOUR ESTIMATED TOTAL</strong><br />
                        <span style="color:#64748b; font-size:14px;">The prices are estimated. Actual prices may be higher or lower depending on current trends. </span>
                    </div>
                    <div class="dtp-total-price" id="dtp-total-price-render">£0.00</div>
                </div>

                <button type="button" class="dtp-btn-submit" onclick="dtp_open_lead_modal();">Book This Package</button>
            </form>
        </div>

        <div class="dtp-modal-overlay" id="dtp-lead-modal">
            <div class="dtp-modal-content">
                <span class="dtp-modal-close" onclick="dtp_close_lead_modal();">&times;</span>
                
                <div id="dtp-modal-form-wrapper">
                    <h3 style="margin-top:0; color:#044343; font-size:20px; font-weight:bold;">Complete Your Booking</h3>
                    <p style="color:#64748b; font-size:13px; margin-bottom:20px;">Provide your contact details below to register and book your custom package.</p>
                    
                    <form id="dtp-lead-form" onsubmit="dtp_process_lead_form_submission(event);">
                        <div class="dtp-form-group">
                            <label>Full Name</label>
                            <input type="text" id="lead_name" class="dtp-select" required />
                        </div>
                        <div class="dtp-form-group">
                            <label>Phone Number</label>
                            <input type="tel" id="lead_phone" class="dtp-select" required />
                        </div>
                        <div class="dtp-form-group">
                            <label>Email Address</label>
                            <input type="email" id="lead_email" class="dtp-select" required />
                        </div>
                        <button type="submit" class="dtp-btn-submit" id="lead-submit-btn">Submit</button>
                    </form>
                </div>

                <div id="dtp-modal-success-wrapper" class="dtp-success-pane">
                    <span style="font-size: 48px; display: block; margin-bottom: 10px; color:#10b981;">✓</span>
                    <h4>Details Submitted Successfully!</h4>
                    <p>Your details are submitted and one of our agents will contact you shortly.</p>
                </div>
            </div>
        </div>

        <script>
            function dtp_refresh_addon_grids_pricing() {
                var currentSeason = document.getElementById('dtp_season_select').value;
                var addonFieldsList = <?php echo wp_json_encode( array_values( array_map(function($f){return $f->id;}, $addon_group_fields) ) ); ?>;
                
                if (addonFieldsList.length === 0) return;

                var formData = new FormData();
                formData.append('action', 'dtp_calculate_price');
                formData.append('dtp_season', currentSeason);
                formData.append('only_get_rates', '1');

                fetch('<?php echo esc_url( admin_url('admin-ajax.php') ); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(res => {
                    if(res.success && res.data.rates_dictionary) {
                        var dictionary = res.data.rates_dictionary;
                        
                        addonFieldsList.forEach(function(fieldId) {
                            var container = document.getElementById('addon-grid-' + fieldId);
                            if (!container) return;

                            var checkedItems = {};
                            container.querySelectorAll('input[type=\"checkbox\"]:checked').forEach(function(cb) {
                                checkedItems[cb.value] = true;
                            });

                            container.innerHTML = '';
                            
                            if (dictionary[fieldId]) {
                                dictionary[fieldId].forEach(function(opt) {
                                    var isChecked = checkedItems[opt.value] ? 'checked' : '';
                                    var card = document.createElement('div');
                                    card.className = 'dtp-addon-card';
                                    card.setAttribute('onclick', 'var cb=this.querySelector(\"input\"); cb.checked=!cb.checked; dtp_trigger_live_recalculation();');
                                    
                                    card.innerHTML = '<div class=\"dtp-addon-left\">' +
                                                     '<input type=\"checkbox\" name=\"fields['+fieldId+'][]\" value=\"'+opt.value+'\" '+isChecked+' onclick=\"event.stopPropagation(); dtp_trigger_live_recalculation();\">' +
                                                     '<span>'+opt.label+'</span>' +
                                                     '</div>' +
                                                     '<div class=\"dtp-addon-price\">+£'+parseInt(opt.price)+'</div>';
                                    
                                    container.appendChild(card);
                                });
                            }
                        });
                    }
                })
                .catch(err => console.error('Addon grid component sync context exception:', err));
            }

            function dtp_trigger_live_recalculation() {
                var formElement = document.getElementById('dtp-calc-form');
                var formData = new FormData(formElement);
                formData.append('action', 'dtp_calculate_price');

                fetch('<?php echo esc_url( admin_url('admin-ajax.php') ); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        document.getElementById('dtp-total-price-render').innerText = '£' + data.data.total;
                    }
                })
                .catch(err => console.error('Pricing recalculation framework exception:', err));
            }

            document.addEventListener('DOMContentLoaded', function() {
                dtp_refresh_addon_grids_pricing();
                
                var seasonDropdown = document.getElementById('dtp_season_select');
                var originalOnChange = seasonDropdown.onchange;
                seasonDropdown.onchange = function() {
                    dtp_refresh_addon_grids_pricing();
                    if(originalOnChange) originalOnChange();
                };

                setTimeout(dtp_trigger_live_recalculation, 300);
            });

            function dtp_open_lead_modal() {
                document.getElementById('dtp-modal-form-wrapper').style.display = 'block';
                document.getElementById('dtp-modal-success-wrapper').style.display = 'none';
                document.getElementById('dtp-lead-modal').style.display = 'flex';
            }

            function dtp_close_lead_modal() {
                document.getElementById('dtp-lead-modal').style.display = 'none';
            }

            function dtp_process_lead_form_submission(e) {
                e.preventDefault();
                var btn = document.getElementById('lead-submit-btn');
                btn.innerText = 'Processing...';
                btn.disabled = true;

                var calcForm = document.getElementById('dtp-calc-form');
                var combinedData = new FormData(calcForm);
                
                combinedData.append('action', 'dtp_submit_lead');
                combinedData.append('cust_name', document.getElementById('lead_name').value);
                combinedData.append('cust_phone', document.getElementById('lead_phone').value);
                combinedData.append('cust_email', document.getElementById('lead_email').value);

                fetch('<?php echo esc_url( admin_url('admin-ajax.php') ); ?>', {
                    method: 'POST',
                    body: combinedData
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        document.getElementById('dtp-modal-form-wrapper').style.display = 'none';
                        document.getElementById('dtp-modal-success-wrapper').style.display = 'block';
                        document.getElementById('dtp-lead-form').reset();
                    } else {
                        alert('System Secure Validation Block Failed: ' + data.data.message);
                    }
                    btn.innerText = 'Submit';
                    btn.disabled = false;
                })
                .catch(err => {
                    console.error('Core network execution tracking instance fault:', err);
                    btn.innerText = 'Submit';
                    btn.disabled = false;
                });
            }
        </script>
        <?php
        return ob_get_clean();
    }

    private function render_frontend_field_item( $field, $wpdb ) {
        ?>
        <div class="dtp-form-group">
            <?php if ( $field->field_type === 'dropdown' ) : 
                $options = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT option_label, option_value FROM {$this->pricing_table} WHERE field_id = %d", $field->id ) );
                ?>
                <label><?php echo esc_html( $field->field_name ); ?></label>
                <select name="fields[<?php echo intval( $field->id ); ?>]" class="dtp-select" onchange="dtp_trigger_live_recalculation();">
                    <?php foreach ( $options as $opt ) : ?>
                        <option value="<?php echo esc_attr( $opt->option_value ); ?>"><?php echo esc_html( $opt->option_label ); ?></option>
                    <?php endforeach; ?>
                </select>
            <?php elseif ( $field->field_type === 'direct' ) : ?>
                <label class="dtp-checkbox-label" style="margin-top: 32px;">
                    <input type="checkbox" name="fields[<?php echo intval( $field->id ); ?>]" value="direct" onchange="dtp_trigger_live_recalculation();" />
                    <?php echo esc_html( $field->field_name ); ?>
                </label>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * AJAX Endpoint: Core Dynamic Price Matrix Solver Execution Logic Node
     */
    public function handle_price_calculation() {
        global $wpdb;

        $season  = isset( $_POST['dtp_season'] ) ? sanitize_text_field( $_POST['dtp_season'] ) : '';
        $persons = isset( $_POST['dtp_persons'] ) ? max( 1, intval( $_POST['dtp_persons'] ) ) : 1;
        $nights  = isset( $_POST['dtp_nights'] ) ? max( 1, intval( $_POST['dtp_nights'] ) ) : 1;
        $posted_fields = isset( $_POST['fields'] ) ? $_POST['fields'] : array();

        $fields = $wpdb->get_results( "SELECT * FROM {$this->fields_table}" );

        if ( isset($_POST['only_get_rates']) && $_POST['only_get_rates'] === '1' ) {
            $dictionary = array();
            foreach ($fields as $field) {
                if ($field->field_type === 'addon_group') {
                    $rows = $wpdb->get_results( $wpdb->prepare("SELECT option_label, option_value, price FROM {$this->pricing_table} WHERE field_id = %d AND season_slug = %s", $field->id, $season) );
                    foreach ($rows as $row) {
                        $dictionary[$field->id][] = array(
                            'label' => $row->option_label,
                            'value' => $row->option_value,
                            'price' => $row->price
                        );
                    }
                }
            }
            wp_send_json_success( array( 'rates_dictionary' => $dictionary ) );
        }

        $running_accumulator_sum = 0.00;

        foreach ( $fields as $field ) {
            if ( ! isset( $posted_fields[$field->id] ) ) {
                continue;
            }

            $is_hotel_field = ( strtolower($field->field_name) === 'hotel' || strtolower($field->field_name) === 'accommodation' );
            $item_price_accumulation = 0.00;

            if ( $field->field_type === 'direct' ) {
                $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT price FROM {$this->pricing_table} WHERE field_id = %d AND season_slug = %s", $field->id, $season ) );
                if ( $price_row ) { $item_price_accumulation = floatval( $price_row->price ); }
            } 
            elseif ( $field->field_type === 'dropdown' ) {
                $selected_opt_val = sanitize_title( $posted_fields[$field->id] );
                $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT price FROM {$this->pricing_table} WHERE field_id = %d AND option_value = %s AND season_slug = %s", $field->id, $selected_opt_val, $season ) );
                if ( $price_row ) { $item_price_accumulation = floatval( $price_row->price ); }
            } 
            elseif ( $field->field_type === 'addon_group' ) {
                $selected_checkboxes = (array) $posted_fields[$field->id];
                foreach ($selected_checkboxes as $chk_val) {
                    $clean_val = sanitize_title($chk_val);
                    $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT price FROM {$this->pricing_table} WHERE field_id = %d AND option_value = %s AND season_slug = %s", $field->id, $clean_val, $season ) );
                    if ( $price_row ) { $item_price_accumulation += floatval( $price_row->price ); }
                }
            }

            // Condition Check: If field identifies as hotel, apply nights modifier layer before running total merge
            if ( $is_hotel_field ) {
                $item_price_accumulation = $item_price_accumulation * $nights;
            }

            $running_accumulator_sum += $item_price_accumulation;
        }

        $final_computed_total = $running_accumulator_sum * $persons;
        wp_send_json_success( array( 'total' => number_format( $final_computed_total, 2, '.', '' ) ) );
    }

    /**
     * AJAX Endpoint: Capture Customer Payload Information Validation Node Injection Loop
     */
    public function handle_lead_submission() {
        global $wpdb;

        $name  = isset( $_POST['cust_name'] ) ? sanitize_text_field( $_POST['cust_name'] ) : '';
        $phone = isset( $_POST['cust_phone'] ) ? sanitize_text_field( $_POST['cust_phone'] ) : '';
        $email = isset( $_POST['cust_email'] ) ? sanitize_email( $_POST['cust_email'] ) : '';

        if ( empty( $name ) || empty( $phone ) || ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => 'Invalid data inputs profiles structural matching schema constraints.' ) );
        }

        $season  = isset( $_POST['dtp_season'] ) ? sanitize_text_field( $_POST['dtp_season'] ) : '';
        $persons = isset( $_POST['dtp_persons'] ) ? max( 1, intval( $_POST['dtp_persons'] ) ) : 1;
        $nights  = isset( $_POST['dtp_nights'] ) ? max( 1, intval( $_POST['dtp_nights'] ) ) : 1;
        $posted_fields = isset( $_POST['fields'] ) ? $_POST['fields'] : array();

        $running_accumulator_sum = 0.00;
        $readable_payload_log    = array();
        $seasons_map = get_option( 'dtp_seasons', array() );

        $readable_payload_log['Selected Operational Season Variant'] = isset($seasons_map[$season]) ? $seasons_map[$season] : $season;
        $readable_payload_log['Total Plan Duration Stay (Nights)'] = $nights;
        $readable_payload_log['Total Registered Number Of Passengers Multiplier'] = $persons;

        $fields = $wpdb->get_results( "SELECT * FROM {$this->fields_table}" );
        foreach ( $fields as $field ) {
            if ( ! isset( $posted_fields[$field->id] ) ) { continue; }
            
            $is_hotel_field = ( strtolower($field->field_name) === 'hotel' || strtolower($field->field_name) === 'accommodation' );
            $item_price_accumulation = 0.00;

            if ( $field->field_type === 'direct' ) {
                $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT price FROM {$this->pricing_table} WHERE field_id = %d AND season_slug = %s", $field->id, $season ) );
                if ( $price_row ) {
                    $item_price_accumulation = floatval( $price_row->price );
                    $readable_payload_log[$field->field_name] = 'Enabled [Base: £' . $item_price_accumulation . ']';
                }
            } 
            elseif ( $field->field_type === 'dropdown' ) {
                $selected_opt_val = sanitize_title( $posted_fields[$field->id] );
                $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT option_label, price FROM {$this->pricing_table} WHERE field_id = %d AND option_value = %s AND season_slug = %s", $field->id, $selected_opt_val, $season ) );
                if ( $price_row ) {
                    $item_price_accumulation = floatval( $price_row->price );
                    $readable_payload_log[$field->field_name] = $price_row->option_label . ' [Base Per-Night: £' . $item_price_accumulation . ']';
                }
            } 
            elseif ( $field->field_type === 'addon_group' ) {
                $selected_checkboxes = (array) $posted_fields[$field->id];
                $chosen_addon_labels = array();
                
                foreach ($selected_checkboxes as $chk_val) {
                    $clean_val = sanitize_title($chk_val);
                    $price_row = $wpdb->get_row( $wpdb->prepare( "SELECT option_label, price FROM {$this->pricing_table} WHERE field_id = %d AND option_value = %s AND season_slug = %s", $field->id, $clean_val, $season ) );
                    if ( $price_row ) {
                        $item_price_accumulation += floatval( $price_row->price );
                        $chosen_addon_labels[] = $price_row->option_label . ' (+£' . $price_row->price . ')';
                    }
                }
                if(!empty($chosen_addon_labels)) {
                    $readable_payload_log[$field->field_name] = $chosen_addon_labels;
                }
            }

            if ( $is_hotel_field ) {
                $item_price_accumulation = $item_price_accumulation * $nights;
                $readable_payload_log[$field->field_name] .= ' [Total Compounded Stay Cost: £' . $item_price_accumulation . ']';
            }

            $running_accumulator_sum += $item_price_accumulation;
        }

        $final_computed_total = $running_accumulator_sum * $persons;

        $inserted = $wpdb->insert( $this->leads_table, array(
            'customer_name'   => $name,
            'customer_email'  => $email,
            'customer_phone'  => $phone,
            'package_payload' => wp_json_encode( $readable_payload_log ),
            'total_price'     => $final_computed_total
        ) );

        if ( $inserted ) {
            wp_send_json_success();
        } else {
            wp_send_json_error( array( 'message' => 'Database write error fault.' ) );
        }
    }
}

new Dynamic_Travel_Pricing_Engine();